/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import config.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import model.Course;

/**
 *
 * @author User
 */
public class CourseDAO {

    Connection conn = DBConnection.getConnection();

    public void insert(Course c) {
        try {

            String sql = "INSERT INTO course(code,name,sks,semester) VALUES(?,?,?,?)";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, c.getCode());
            ps.setString(2, c.getName());
            ps.setInt(3, c.getSKS());
            ps.setInt(4, c.getSemester());

            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ArrayList<Course> getAll() {

        ArrayList<Course> list = new ArrayList<>();

        try {

            String sql = "SELECT * FROM course";

            PreparedStatement ps = conn.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Course c = new Course();

                c.setId(rs.getInt("id"));
                c.setCode(rs.getString("code"));
                c.setName(rs.getString("name"));
                c.setSKS(rs.getInt("sks"));
                c.setSemester(rs.getInt("semester"));

                list.add(c);

            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    public void update(Course c) {

        try {

            String sql = "UPDATE course SET code=?, name=?, sks=?, semester=? WHERE id=?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, c.getCode());
            ps.setString(2, c.getName());
            ps.setInt(3, c.getSKS());
            ps.setInt(4, c.getSemester());
            ps.setInt(5, c.getId());

            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void delete(int id) {

        try {

            String sql = "DELETE FROM course WHERE id=?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setInt(1, id);

            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ArrayList<Course> search(String keyword) {

        ArrayList<Course> list = new ArrayList<>();

        try {

            String sql = "SELECT * FROM course WHERE name LIKE ? OR code LIKE ?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, "%" + keyword + "%");
            ps.setString(2, "%" + keyword + "%");

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Course c = new Course();

                c.setId(rs.getInt("id"));
                c.setCode(rs.getString("code"));
                c.setName(rs.getString("name"));
                c.setSKS(rs.getInt("sks"));
                c.setSemester(rs.getInt("semester"));

                list.add(c);

            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    public ArrayList<Course> getPage(int offset, int limit) {

        ArrayList<Course> list = new ArrayList<>();

        try {

            String sql = "SELECT * FROM course LIMIT ?, ?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setInt(1, offset);
            ps.setInt(2, limit);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Course c = new Course();

                c.setId(rs.getInt("id"));
                c.setCode(rs.getString("code"));
                c.setName(rs.getString("name"));
                c.setSKS(rs.getInt("sks"));
                c.setSemester(rs.getInt("semester"));

                list.add(c);

            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
}