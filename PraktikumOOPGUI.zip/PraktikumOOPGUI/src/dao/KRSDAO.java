/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import config.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import model.KRS;

/**
 *
 * @author User
 */
public class KRSDAO {

    Connection conn = DBConnection.getConnection();

    // INSERT
    public void insert(KRS k) {
        try {
            String sql = "INSERT INTO krs(nim,student_id,course_id,semester,tugas,uts,uas,nilai_akhir,nilai_huruf) VALUES(?,?,?,?,?,?,?,?,?)";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, k.getNim());
            ps.setInt(2, k.getStudentId());
            ps.setInt(3, k.getCourseId());
            ps.setInt(4, k.getSemester());
            ps.setDouble(5, k.getTugas());
            ps.setDouble(6, k.getUts());
            ps.setDouble(7, k.getUas());
            ps.setDouble(8, k.getNilaiAkhir());
            ps.setString(9, k.getNilaiHuruf());

            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // GET ALL
    public ArrayList<KRS> getAll() {

    ArrayList<KRS> list = new ArrayList<>();

    try {

        String sql =
            "SELECT k.nim, s.name AS nama, c.name AS mata_kuliah, " +
            "k.semester, k.tugas, k.uts, k.uas, " +
            "k.nilai_akhir, k.nilai_huruf " +
            "FROM krs k " +
            "JOIN student s ON k.student_id = s.id " +
            "JOIN course c ON k.course_id = c.id";

        PreparedStatement ps = conn.prepareStatement(sql);

        ResultSet rs = ps.executeQuery();

        while (rs.next()) {

            KRS k = new KRS();

            k.setNim(rs.getString("nim"));
            k.setNama(rs.getString("nama"));
            k.setMataKuliah(rs.getString("mata_kuliah"));
            k.setSemester(rs.getInt("semester"));
            k.setTugas(rs.getDouble("tugas"));
            k.setUts(rs.getDouble("uts"));
            k.setUas(rs.getDouble("uas"));
            k.setNilaiAkhir(rs.getDouble("nilai_akhir"));
            k.setNilaiHuruf(rs.getString("nilai_huruf"));

            list.add(k);
        }

    } catch (Exception e) {
        e.printStackTrace();
    }

    return list;
}

    // UPDATE
    public void update(KRS k){

        try{

            String sql="UPDATE krs SET student_id=?, course_id=?, semester=?, tugas=?, uts=?, uas=?, nilai_akhir=?, nilai_huruf=? WHERE nim=?";

            PreparedStatement ps=conn.prepareStatement(sql);

            ps.setInt(1,k.getStudentId());
            ps.setInt(2,k.getCourseId());
            ps.setInt(3,k.getSemester());
            ps.setDouble(4,k.getTugas());
            ps.setDouble(5,k.getUts());
            ps.setDouble(6,k.getUas());
            ps.setDouble(7,k.getNilaiAkhir());
            ps.setString(8,k.getNilaiHuruf());
            ps.setString(9,k.getNim());

            ps.executeUpdate();

        }catch(Exception e){
            e.printStackTrace();
        }

    }

    // DELETE
    public void delete(String nim){

        try{

            String sql="DELETE FROM krs WHERE nim=?";

            PreparedStatement ps=conn.prepareStatement(sql);

            ps.setString(1,nim);

            ps.executeUpdate();

        }catch(Exception e){
            e.printStackTrace();
        }

    }

    // SEARCH
    public ArrayList<KRS> search(String keyword){

        ArrayList<KRS> list=new ArrayList<>();

        try{

            String sql="SELECT * FROM krs WHERE nim LIKE ?";

            PreparedStatement ps=conn.prepareStatement(sql);

            ps.setString(1,"%"+keyword+"%");

            ResultSet rs=ps.executeQuery();

            while (rs.next()) {

        KRS k = new KRS();

        k.setNim(rs.getString("nim"));
        k.setNama(rs.getString("nama"));
        k.setMataKuliah(rs.getString("mata_kuliah"));
        k.setSemester(rs.getInt("semester"));
        k.setTugas(rs.getDouble("tugas"));
        k.setUts(rs.getDouble("uts"));
        k.setUas(rs.getDouble("uas"));
        k.setNilaiAkhir(rs.getDouble("nilai_akhir"));
        k.setNilaiHuruf(rs.getString("nilai_huruf"));

        list.add(k);
    }

        }catch(Exception e){
            e.printStackTrace();
        }

        return list;

    }

}   
