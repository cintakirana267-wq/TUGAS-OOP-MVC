/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import config.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import model.Lecturer;
/**
 *
 * @author User
 */
public class LecturerDAO {

    Connection conn = DBConnection.getConnection();

    public void insert(Lecturer l) {
        try {
            String sql = "INSERT INTO lecturer(nidn, nik, name, expertise) VALUES (?, ?, ?, ?)";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, l.getNidn());
            ps.setString(2, l.getNik());
            ps.setString(3, l.getName());
            ps.setString(4, l.getExpertise());

            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ArrayList<Lecturer> getAll() {

        ArrayList<Lecturer> list = new ArrayList<>();

        try {

            String sql = "SELECT * FROM lecturer";

            PreparedStatement ps = conn.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Lecturer l = new Lecturer();

                l.setNidn(rs.getString("nidn"));
                l.setNik(rs.getString("nik"));
                l.setName(rs.getString("name"));
                l.setExpertise(rs.getString("expertise"));

                list.add(l);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    public void update(Lecturer l) {
        try {

            String sql = "UPDATE lecturer SET nik=?, name=?, expertise=? WHERE nidn=?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, l.getNik());
            ps.setString(2, l.getName());
            ps.setString(3, l.getExpertise());
            ps.setString(4, l.getNidn());

            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void delete(String nidn) {
        try {

            String sql = "DELETE FROM lecturer WHERE nidn=?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, nidn);

            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ArrayList<Lecturer> search(String keyword) {

        ArrayList<Lecturer> list = new ArrayList<>();

        try {

            String sql = "SELECT * FROM lecturer WHERE name LIKE ? OR nidn LIKE ?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, "%" + keyword + "%");
            ps.setString(2, "%" + keyword + "%");

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Lecturer l = new Lecturer();

                l.setNidn(rs.getString("nidn"));
                l.setNik(rs.getString("nik"));
                l.setName(rs.getString("name"));
                l.setExpertise(rs.getString("expertise"));

                list.add(l);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    public ArrayList<Lecturer> getPage(int offset, int limit) {

        ArrayList<Lecturer> list = new ArrayList<>();

        try {

            String sql = "SELECT * FROM lecturer LIMIT ?, ?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setInt(1, offset);
            ps.setInt(2, limit);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Lecturer l = new Lecturer();

                l.setNidn(rs.getString("nidn"));
                l.setNik(rs.getString("nik"));
                l.setName(rs.getString("name"));
                l.setExpertise(rs.getString("expertise"));

                list.add(l);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
}