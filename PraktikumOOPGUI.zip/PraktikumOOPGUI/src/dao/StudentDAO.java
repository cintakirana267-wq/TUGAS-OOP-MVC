/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import config.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import model.Student;

/**
 *
 * @author User
 */
public class StudentDAO {

    Connection conn = DBConnection.getConnection();

    public void insert(Student s) {
        try {
            String sql = "INSERT INTO student(nim, nik, name, course_id) VALUES (?, ?, ?, ?)";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, s.getNim());
            ps.setString(2, s.getNik());
            ps.setString(3, s.getName());
            ps.setInt(4, s.getCourseId());

            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ArrayList<Student> getAll() {
        ArrayList<Student> list = new ArrayList<>();

        try {
            String sql = "SELECT * FROM student";

            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Student s = new Student();

                s.setNim(rs.getString("nim"));
                s.setNik(rs.getString("nik"));
                s.setName(rs.getString("name"));
                s.setCourseId(rs.getInt("course_id"));

                list.add(s);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
    
    public void update(Student s) {
    try {
        String sql = "UPDATE student SET nik=?, name=?, course_id=? WHERE nim=?";

        PreparedStatement ps = conn.prepareStatement(sql);

        ps.setString(1, s.getNik());
        ps.setString(2, s.getName());
        ps.setInt(3, s.getCourseId());
        ps.setString(4, s.getNim());

        ps.executeUpdate();

    } catch (Exception e) {
        e.printStackTrace();
    }
  }
    
    public void delete(String nim) {
    try {
        String sql = "DELETE FROM student WHERE nim=?";

        PreparedStatement ps = conn.prepareStatement(sql);

        ps.setString(1, nim);

        ps.executeUpdate();

    } catch (Exception e) {
        e.printStackTrace();
    }
 }
    public ArrayList<Student> search(String keyword) {

    ArrayList<Student> list = new ArrayList<>();

    try {

        String sql = "SELECT * FROM student WHERE name LIKE ? OR nim LIKE ?";

        PreparedStatement ps = conn.prepareStatement(sql);

        ps.setString(1, "%" + keyword + "%");
        ps.setString(2, "%" + keyword + "%");

        ResultSet rs = ps.executeQuery();

        while (rs.next()) {

            Student s = new Student();

            s.setNim(rs.getString("nim"));
            s.setNik(rs.getString("nik"));
            s.setName(rs.getString("name"));
            s.setCourseId(rs.getInt("course_id"));

            list.add(s);
        }

    } catch (Exception e) {
        e.printStackTrace();
    }

    return list;
 }
    
    public ArrayList<Student> getPage(int offset, int limit) {

    ArrayList<Student> list = new ArrayList<>();

    try {

        String sql = "SELECT * FROM student LIMIT ?, ?";

        PreparedStatement ps = conn.prepareStatement(sql);

        ps.setInt(1, offset);
        ps.setInt(2, limit);

        ResultSet rs = ps.executeQuery();

        while (rs.next()) {

            Student s = new Student();

            s.setId(rs.getInt("id"));
            s.setNim(rs.getString("nim"));
            s.setNik(rs.getString("nik"));
            s.setName(rs.getString("name"));
            s.setCourseId(rs.getInt("course_id"));

            list.add(s);
        }

    } catch (Exception e) {
        e.printStackTrace();
    }

    return list;
  }
}