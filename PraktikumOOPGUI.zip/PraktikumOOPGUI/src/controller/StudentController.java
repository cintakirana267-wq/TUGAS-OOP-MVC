/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import dao.StudentDAO;
import java.util.ArrayList;
import model.Student;
/**
 *
 * @author User
 */

public class StudentController {

    StudentDAO dao = new StudentDAO();

    public void save(Student s) {
        dao.insert(s);
    }
    
     public void update(Student s) {
        dao.update(s);
    }

     public void delete(String nim) {
        dao.delete(nim);
    }

     public ArrayList<Student> search(String keyword) {
        return dao.search(keyword);
    }
     
     public ArrayList<Student> getPage(int offset, int limit) {
    return dao.getPage(offset, limit);
    }
     
    public ArrayList<Student> getAll() {
        return dao.getAll();
    }
}

