/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import dao.UserDAO;
import model.User;
/**
 *
 * @author User
 */
public class UserController {

    UserDAO dao = new UserDAO();

    public void register(User u) {
        dao.register(u);
    }
}
  
