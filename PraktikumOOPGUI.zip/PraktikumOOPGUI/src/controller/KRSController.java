/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import dao.KRSDAO;
import java.util.ArrayList;
import model.KRS;
import controller.StudentController;
import controller.CourseController;
/**
 *
 * @author User
 */
public class KRSController {

    KRSDAO dao = new KRSDAO();

    public void save(KRS k) {

        double akhir = (k.getTugas() + k.getUts() + k.getUas()) / 3;

        k.setNilaiAkhir(akhir);

        if (akhir >= 85) {
            k.setNilaiHuruf("A");
        } else if (akhir >= 75) {
            k.setNilaiHuruf("B");
        } else if (akhir >= 60) {
            k.setNilaiHuruf("C");
        } else if (akhir >= 40) {
            k.setNilaiHuruf("D");
        } else {
            k.setNilaiHuruf("E");
        }

        dao.insert(k);
    }

    public void update(KRS k) {

        double akhir = (k.getTugas() + k.getUts() + k.getUas()) / 3;

        k.setNilaiAkhir(akhir);

        if (akhir >= 85) {
            k.setNilaiHuruf("A");
        } else if (akhir >= 75) {
            k.setNilaiHuruf("B");
        } else if (akhir >= 60) {
            k.setNilaiHuruf("C");
        } else if (akhir >= 40) {
            k.setNilaiHuruf("D");
        } else {
            k.setNilaiHuruf("E");
        }

        dao.update(k);
    }

    public void delete(String nim) {
        dao.delete(nim);
    }

    public ArrayList<KRS> getAll() {
        return dao.getAll();
    }

    public ArrayList<KRS> search(String keyword) {
        return dao.search(keyword);
    }
}