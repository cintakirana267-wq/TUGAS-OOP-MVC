/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import dao.CourseDAO;
import java.util.ArrayList;
import model.Course;
/**
 *
 * @author User
 */
public class CourseController {
    

    CourseDAO dao = new CourseDAO();

    public void save(Course c) {
        dao.insert(c);
    }

    public void update(Course c) {
        dao.update(c);
    }

    public void delete(int id) {
        dao.delete(id);
    }

    public ArrayList<Course> search(String keyword) {
        return dao.search(keyword);
    }

    public ArrayList<Course> getPage(int offset, int limit) {
        return dao.getPage(offset, limit);
    }

    public ArrayList<Course> getAll() {
        return dao.getAll();
    }
}