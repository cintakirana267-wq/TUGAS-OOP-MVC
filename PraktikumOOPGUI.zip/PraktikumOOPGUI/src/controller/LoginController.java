/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import dao.UserDAO;
import model.User;
/**
 *
 * @author User
 */
public class LoginController {
    
    UserDAO dao = new UserDAO();

    public boolean login(String email, String password) {

        User u = dao.findByEmail(email);

        if (u == null) {
            return false;
        }

        if (u.getPassword().equals(password)) {
            return true;
        } else {
            return false;
        }
    }
}