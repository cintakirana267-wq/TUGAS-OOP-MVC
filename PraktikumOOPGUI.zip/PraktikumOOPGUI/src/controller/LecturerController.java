/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import dao.LecturerDAO;
import java.util.ArrayList;
import model.Lecturer;
/**
 *
 * @author User
 */
public class LecturerController {

    LecturerDAO dao = new LecturerDAO();

    public void save(Lecturer l) {
        dao.insert(l);
    }

    public void update(Lecturer l) {
        dao.update(l);
    }

    public void delete(String nidn) {
        dao.delete(nidn);
    }

    public ArrayList<Lecturer> search(String keyword) {
        return dao.search(keyword);
    }

    public ArrayList<Lecturer> getPage(int offset, int limit) {
        return dao.getPage(offset, limit);
    }

    public ArrayList<Lecturer> getAll() {
        return dao.getAll();
    }
}
