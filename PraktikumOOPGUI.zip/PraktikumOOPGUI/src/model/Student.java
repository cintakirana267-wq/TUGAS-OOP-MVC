/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
package model;

import java.util.ArrayList;

public class Student extends Person {
    
    private int id;
    private String nim;
    private String studyProgram;
    private int courseId;
    private ArrayList<KRS> krsList;

    public Student() {
        krsList = new ArrayList<>();
    }

    public Student(String nik, String name, String nim, String studyProgram) {
        super(nik, name);
        this.nim = nim;
        this.studyProgram = studyProgram;
        this.krsList = new ArrayList<>();
    }

    public int getId() {
    return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNim() {
        return nim;
    }

    public void setNim(String nim) {
        this.nim = nim;
    }

    public String getStudyProgram() {
        return studyProgram;
    }

    public void setStudyProgram(String studyProgram) {
        this.studyProgram = studyProgram;
    }

    public int getCourseId() {
        return courseId;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }
    
    public void addKRS(KRS krs) {
        krsList.add(krs);
    }

    public String toString() {
        return name;
    }
}