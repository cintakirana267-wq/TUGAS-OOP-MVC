/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
package model;

public class Lecturer extends Person {

    private String nidn;
    private String expertise;

    public Lecturer() {
    }

    public Lecturer(String nik, String name, String nidn, String expertise) {
        super(nik, name);
        this.nidn = nidn;
        this.expertise = expertise;
    }

    public String getNidn() {
        return nidn;
    }

    public void setNidn(String nidn) {
        this.nidn = nidn;
    }

    public String getExpertise() {
        return expertise;
    }

    public void setExpertise(String expertise) {
        this.expertise = expertise;
    }

    @Override
    public String toString() {
        return name;
    }
}